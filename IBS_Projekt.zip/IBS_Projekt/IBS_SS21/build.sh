#!/bin/bash

docker-compose up --build

# docker-compose up --build nodecollect mongodb mysql mqtt nodeexpressapi